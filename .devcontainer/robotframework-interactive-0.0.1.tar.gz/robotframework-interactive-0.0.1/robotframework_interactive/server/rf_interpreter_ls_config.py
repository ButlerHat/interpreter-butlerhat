from robocorp_ls_core.config import Config

from .rf_interpreter_generated_lsp_constants import *  # @UnusedWildImport


class RfInterpreterRobotConfig(Config):
    ALL_OPTIONS = ALL_ROBOT_OPTIONS
