from robocorp_ls_core.options import *  # @UnusedWildImport (backward compatibility)


class Options(BaseOptions):
    pass
